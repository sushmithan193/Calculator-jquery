module.exports = {
  encodeWithBaseDir: {
    files: {
      "lib/jasmine-core/jasmine.css": ["lib/jasmine-core/jasmine.css"]
    }
  }
};
